package com.example.pert10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
